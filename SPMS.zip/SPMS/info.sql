-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2024 at 08:38 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `permision`
--

CREATE TABLE `permision` (
  `id` int(11) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permision`
--

INSERT INTO `permision` (`id`, `reason`, `status`) VALUES
(10, 'Financial Problems', 'Pending'),
(11, 'Friend Death', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` tinyint(1) NOT NULL,
  `failed_attempts` int(11) DEFAULT 0,
  `last_attempt_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `username`, `password`, `role`, `failed_attempts`, `last_attempt_time`) VALUES
(9, 'Elisha Mahenda', 'mahendaelisha60@gmail.com', '12345', '$2y$10$.DVeeJp37lGlxf3wS8gOh.f4FdTPbUzAxY.MLHJVUcs0w/fhq4ksm', 1, 3, '2024-06-11 06:50:50'),
(10, 'Rehema Juma', 'rey@gmail.com', '21-0100', '$2y$10$Fl57WZC3kkaV.h9u3NM17.lJdrhN06/f/wls1WK7equPs0.1ILIBG', 0, 0, NULL),
(11, 'Kenedy Juma', 'keny@gmail.com', '21-0200', '$2y$10$pWMd0FbLIXV8QwRfz.dYeu4JKPY5DtIMEyeorbfr/Wx26Zia7eDq2', 0, 0, NULL),
(12, 'Omary Hassan', 'ommy@gmail.com', '21-0300', '$2y$10$pLBTq9mYl95ahx3lrADJcusawzigLhXfXsk612eig1YA/YWG94z4.', 0, 0, NULL),
(13, 'Joseph Wafaida', 'jose@gmail.com', '21-0400', '$2y$10$CXXoX8kWTbCFDIO3f3Jtzuards1bW4N31HKDtINBjkYskA4gZlk86', 0, 0, NULL),
(14, 'Isaac Mahenge', 'mahenge@gmail.com', '21-1000', '$2y$10$jeztppIu1ylQemXxvhqviu9bZeNgB8XWc59dw7bFW9hJRSQCZtRp6', 1, 0, NULL),
(16, 'Matogoto', 'matogoro@gmail.com', '21-9000', '$2y$10$HH4Of8TIGch7uI4N0AfcUe/hzCH8LTHeYg51mZmWO7ZqB71V59.GG', 1, 3, '2024-06-11 11:31:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `permision`
--
ALTER TABLE `permision`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `permision`
--
ALTER TABLE `permision`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
