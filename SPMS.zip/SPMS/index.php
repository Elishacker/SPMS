<?php
// Include database connection file
include('config.php');

// Start session
session_start();

// Generate CSRF token if it doesn't exist
if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check if user is already logged in
if (isset($_SESSION['username'])) {
    // Redirect user to their appropriate page
    if ($_SESSION['role'] == 1) {
        header("Location: admin.php");
        exit();
    } elseif ($_SESSION['role'] == 0) {
        header("Location: dashboard.php");
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Validate CSRF token
  if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
      die('CSRF token validation failed');
  }

  // Proceed with the rest of your login logic
  $username = $_POST['username'];
  $password = $_POST['password'];

  // Check if the username length is valid
  if (strlen($username) > 8) {
      $error = "Username must be 8 characters or less!";
  } else {
      // Use prepared statements to prevent SQL injection
      $stmt = $conn->prepare("SELECT username, password, role, failed_attempts, last_attempt_time FROM user WHERE username = ?");
      $stmt->bind_param("s", $username);
      $stmt->execute();
      $stmt->store_result();
      
      if ($stmt->num_rows > 0) {
          $stmt->bind_result($username, $passwordHash, $role, $failedAttempts, $lastAttemptTime);
          $stmt->fetch();
          
          // Check if account is locked
          $lockoutTime = 10; // lockout time in seconds
          $currentTime = new DateTime();
          $lastAttemptDateTime = new DateTime($lastAttemptTime);
          $timeDiff = $currentTime->getTimestamp() - $lastAttemptDateTime->getTimestamp();
          
          if ($failedAttempts >= 3 && $timeDiff < $lockoutTime) {
              $error = "Account is locked. Please try again later.";
          } else {
              // Verify password
              if (password_verify($password, $passwordHash)) {
                  $_SESSION['username'] = $username;
                  $_SESSION['role'] = $role;
                  
                  // Reset failed attempts on successful login
                  $resetStmt = $conn->prepare("UPDATE user SET failed_attempts = 0, last_attempt_time = NULL WHERE username = ?");
                  $resetStmt->bind_param("s", $username);
                  $resetStmt->execute();
                  $resetStmt->close();
                  
                  // Redirect based on role
                  if ($role == 1) {
                      header("Location: admin.php");
                  } elseif ($role == 0) {
                      header("Location: dashboard.php");
                  } else {
                      $error = "Unknown role!";
                  }
                  exit();
              } else {
                  // Invalid password, increment failed attempts
                  $failedAttempts++;
                  $updateStmt = $conn->prepare("UPDATE user SET failed_attempts = ?, last_attempt_time = NOW() WHERE username = ?");
                  $updateStmt->bind_param("is", $failedAttempts, $username);
                  $updateStmt->execute();
                  $updateStmt->close();
                  
                  if ($failedAttempts >= 3) {
                      $error = "Account is locked. Please try again later.";
                  } else {
                      $error = "Invalid password!";
                  }
              }
          }
      } else {
          $error = "Invalid username!";
      }
      $stmt->close();
  }
}

// Logout functionality
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Login | SPMS</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
  <main>
    <div class="container">
      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">
              <div class="d-flex justify-content-center py-4">
                <a href="index.html" class="logo d-flex align-items-center w-auto">
                  <img src="assets/img/logo.png" alt="">
                  <span class="d-none d-lg-block">SPMS</span>
                </a>
              </div>
              <div class="card mb-3">
                <div class="card-body">
                  <div class="pt-4 pb-2">
                    <h5 class="card-title text-center pb-0 fs-4">Login to Your Account</h5>
                    <p class="text-center small">Enter your username & password to login</p>
                  </div>
                  <?php if (!empty($error)): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo $error; ?>
                    </div>
                  <?php endif; ?>
                  <form action="index.php" method="POST" class="row g-3 needs-validation" novalidate>
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <div class="col-12">
                        <label for="yourUsername" class="form-label">Username</label>
                        <div class="input-group has-validation">
                            <span class="input-group-text" id="inputGroupPrepend"><img src="./people.png" height="15fpx" width="15px"></span>
                            <input type="text" name="username" class="form-control" id="yourUsername" required>
                            <div class="invalid-feedback">Please enter your username.</div>
                        </div>
                    </div>
                    <div class="col-12">
                        <label for="yourPassword" class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" id="yourPassword" required>
                        <div class="invalid-feedback">Please enter your password!</div>
                    </div>
                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" value="true" id="rememberMe">
                            <label class="form-check-label" for="rememberMe">Remember me</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <button class="btn btn-primary w-100" type="submit">Login</button>
                    </div>
                </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </main>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/js/main.js"></script>
</body>
</html>