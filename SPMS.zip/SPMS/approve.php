<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    // Update the status to 'Approved'
    $query = "UPDATE permision SET status='Approved' WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
}

$conn->close();

// Redirect back to the main page
header('Location: pending.php');
exit();
?>
