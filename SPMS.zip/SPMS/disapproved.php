<?php
include('config.php');

$query = "
    SELECT 
        permision.id AS id, 
        user.name, 
        user.username, 
        permision.reason 
    FROM 
        permision 
    JOIN 
        user
    ON 
        permision.user_id = user.id 
    WHERE 
        permision.status = 'Disapproved'
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disapproved Permissions</title>
    <style>
        table {
            width: 60%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Disapproved Permissions</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Username</th>
            <th>Reason</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['username'] . "</td>";
                echo "<td>" . $row['reason'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No disapproved permissions found</td></tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>
